<?php


namespace App\Models;

use Eloquent;
use DB;

class UserInformation extends Eloquent {
    
    protected $table = 'tt_user_information';
    public $timestamps = true;
    public $created_at = 'create_time';
    public $updated_at = 'update_time';
    
    public function getEmailUser($email) {
        $query = DB::table('tt_user_information')
                ->select('tt_user_information.*')
                ->where('tt_user_information.email', '=', $email);
        $query->first();
        return $query->get();
    }
    
}