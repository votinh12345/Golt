<?php

namespace App\Models;

use Eloquent;
use DB;
use Auth;
use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Auth\Passwords\CanResetPassword;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;

class User extends Eloquent implements AuthenticatableContract {

    use Authenticatable;

    /**
     * Table Name
     * @var unknown_type
     */
    protected $table = 'tt_user';

    /**
     * Set Primary Key
     * @var unknown_type
     */
    protected $primaryKey = 'user_id';
    public $timestamps = true;
    public $created_at = 'create_time';
    public $updated_at = 'update_time';
    protected $fillable = ['email', 'password'];
    

    public function getAuthIdentifier() {
        return $this->user_id;
    }

    public function getAuthPassword() {
        return $this->password;
    }

    /**
     * get Remember Token
     */
    public function getRememberToken() {
        return $this->remember_token;
    }

    /**
     * Set Remember Token
     */
    public function setRememberToken($value) {
        $this->remember_token = $value;
    }

    /**
     * Set Remember Token Name
     */
    public function getRememberTokenName() {
        return 'remember_token';
    }
    /*
     * Get info list member online
     */
    
    public function getUserOnline(){
        $query = DB::table('tt_user')
                ->select('tt_user.*')
                ->where('tt_user.user_id', '<>', Auth::user()->user_id)
                ->where('tt_user.is_online', '=', 1);
        return $query->get();
    }
    /*
     * Get info member
     */
    
    public function getInfo($user_id){
        $query = DB::table('tt_user')
                ->select('tt_user.*','tt_user_information.*')
                ->join('tt_user_information', 'tt_user_information.user_id', '=', 'tt_user.user_id')
                ->where('tt_user.user_id', '=', $user_id)
                ->where('tt_user_information.is_deleted', '=', 0);  
        $query->first();
        return $query->get();
    }

}
