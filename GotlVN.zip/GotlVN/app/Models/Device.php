<?php

namespace App\Models;

use Eloquent;
use DB;

class Device extends Eloquent {

    protected $table = 'tt_device';
    public $timestamps = true;
    public $created_at = 'create_time';
    public $updated_at = 'update_time';

    public function getAccessKey($token) {
        $query = DB::table('tt_device')
                ->select('tt_device.*')
                ->where('tt_device.access_key', '=', $token);
        $query->first();
        return $query->get();
    }
    
    public function updateToken($memberId, $token){
        DB::table('tt_device')
                ->where('user_id', $memberId)
                ->update(['access_key' => $token,'expire_date' => date("Y-m-d H:i:s", strtotime('+2 hours'))]);
        
        return TRUE;
    }

}
