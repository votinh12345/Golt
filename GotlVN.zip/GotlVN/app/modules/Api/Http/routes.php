<?php

Route::group(['domain' => 'api.' . Config::get('app.domain'), 'namespace' => 'Modules\Api\Http\Controllers'], function() {
    Route::get('/', 'ApiController@index');
    Route::post('/member/create', array('uses' => 'MemberController@create'));
    Route::get('/member/detail', array('uses' => 'MemberController@detail'));
});
