<?php

namespace Modules\Api\Http\Controllers;

use Pingpong\Modules\Routing\Controller;
use Illuminate\Http\Response;
use Request;
use Session;
use Hash;
use DB;
use App\Models\User;
use App\Models\UserInformation;
use App\Models\Device;
use ApiHelper;

class MemberController extends Controller {

    public function create() {
        $data = Request::input();
        $reason = array();
        $user = new UserInformation();
        //check param
        if (!isset($data['user_name']) || ($data['user_name'] == '')) {
            $reason['user_name'] = 'Bạn chưa nhập user_name.';
        }
        if (!isset($data['password']) || ($data['password'] == '')) {
            $reason['password'] = 'Bạn chưa nhập password';
        }
        if (!isset($data['email']) || ($data['email'] == '')) {
            $reason['email'] = 'Bạn chưa nhập email.';
        } else {
            //check formart email
            if (!preg_match('/^[A-z0-9_\-]+[@][A-z0-9_\-]+([.][A-z0-9_\-]+)+[A-z.]{2,4}$/', $data['email'])) {
                $reason['email'] = 'Email không đúng định dạng.';
            }
            //check exit email
            $member = $user->getEmailUser($data['email']);
            if ($member) {
                $reason['email'] = 'Email đã tồn tại.';
            }
        }

        if (!empty($reason)) {
            $result = array(
                'result' => 0,
                'reason' => $reason
            );
        } else {
            //insert tt_user table
            $member = new User();
            $member->user_name = $data['user_name'];
            $member->password = Hash::make($data['password']);
            $member->create_time = date('Y-m-d H:i:s');
            if ($member->save()) {
                //insert tt_user_information table
                $user->user_id = $member->user_id;
                $user->full_name = '';
                $user->email = $data['email'];
                $user->birthday = isset($data['birthday']) ? $data['birthday'] : '';
                $user->gender = isset($data['gender']) ? $data['gender'] : '';
                $user->create_time = date('Y-m-d H:i:s');

                if ($user->save()) {
                    //insert member_access_tokens table
                    //create access token
                    $apiHelper = new ApiHelper();
                    $accessToken = $apiHelper->generateAccessToken();
                    $device = new Device();
                    $device->user_id = $member->user_id;
                    $device->access_key = $accessToken;
                    $device->create_time = date("Y-m-d H:i:s");
                    $device->expire_date = date("Y-m-d H:i:s", strtotime('+2 hours'));
                    $device->save();
                    $result = array(
                        'result' => 1,
                        'data' => array(
                            'id' => $member->user_id,
                            'access_token' => $accessToken,
                        )
                    );
                } else {
                    $result = array(
                        'result' => 0,
                        'reason' => 'Lỗi hệ thống'
                    );
                }
            } else {
                $result = array(
                    'result' => 0,
                    'reason' => 'Lỗi hệ thống'
                );
            }
        }

        return response()->json($result);
    }

    public function detail() {
        $apiHelper = new ApiHelper();
        $data = Request::all();
        $reason = array();
        $accessToken = Request::header('X-Access-Token');
        $token = $apiHelper->checkAccessToken($accessToken);
        if ($token['result'] == 0) {
            $result = $token;
        } else {
            //check param
            if (!isset($data['user_id']) || ($data['user_id'] == '')) {
                $reason['user_id'] = 'Bạn chưa nhập user_id';
            }
            if (!empty($reason)) {
                $result = array(
                    'result' => 0,
                    'reason' => $reason
                );
            } else {
                $user = new User();
                $info = $user->getInfo($data['user_id']);
                if (count($info) == 0) {
                    $result = array(
                        'result' => 0,
                        'reason' => array('NO_DATA' => 'Không tồn tại dữ liệu.')
                    );
                } else {
                    $result = array(
                        'result' => 1,
                        'data' => array(
                            'user_id' => (int) $info[0]->user_id,
                            'user_name' => $info[0]->user_name,
                            'full_name' => $info[0]->full_name,
                            'email' => $info[0]->email,
                            'birthday' => $info[0]->birthday,
                            'gender' => $info[0]->gender,
                            'credits' => $info[0]->credits,
                            'rate' => $info[0]->rate,
                            'is_deleted' => $info[0]->is_deleted,
                        )
                    );
                }
            }
        }
        return response()->json($result);
    }

}
