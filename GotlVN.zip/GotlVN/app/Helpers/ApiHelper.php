<?php

use App\Models\Device;
use Illuminate\Http\Response;

class ApiHelper {

    public function checkAccessToken($token = NULL) {
        if ($token != NULL) {
            $device = new Device();
            $memberToken = $device->getAccessKey($token);
            if (count($memberToken) > 0) {
                if (strtotime($memberToken[0]->expire_date) >= time()) {
                    $result = array(
                        'result' => 1,
                        'user_id' => $memberToken[0]->user_id
                    );
                } else {
                    $result = array(
                        'result' => 2,
                        'token' => $this->generateAccessToken(),
                        'user_id' => $memberToken[0]->user_id
                    );

                    $this->updateAccessToken($memberToken[0]->user_id, $result['token']);
//                    response($content, $status)->header('X-New-Access-Token', $result['token']);
                }
            } else {
                $result = array(
                    'reason' => array('authentication_failure' => 'Access token is invalid.'),
                    'result' => 0
                );
            }
        } else {
            $result = array(
                'reason' => array('authentication_failure' => 'Access token is invalid.'),
                'result' => 0
            );
        }

        return $result;
    }

    public function updateAccessToken($memberId, $token) {
        $device = new Device();
        $device->updateToken($memberId, $token);
		return TRUE;
	}
    
    function generateAccessToken() {
        return $this->ramdomToken(64);
    }

    function ramdomToken($bit) {
        $characterList = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        $i = 0;
        $salt = "";
        while ($i < $bit) {
            $salt .= $characterList{mt_rand(0, (strlen($characterList) - 1))};
            $i++;
        }

        return $salt;
    }

}
