<?php namespace App\Http\Controllers;

use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Input;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Request;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Validator;
use View;
use Session;
use Hash;
use Auth;
use DB; 
use App\Models\User;

class UserController extends Controller {
    
    public function getRegistration(){
        return view('auth.register');
    }
    
    public function postRegistration(){
        $input = Request::all();
        $result = array(
            'success' => 0
        );
        $user = new User();
        $email_member = $user->getEmailUser($input['email']);
        if (empty($email_member)) {
            $user->email = $input['email'];
            $user->password = Hash::make($input['password']);
            $user->user_name = $input['name'];
            $user->create_time = date('Y-m-d H:i:s');   
            $user->save();
            return Redirect::to('/');
        } else {
            
        }
    }
    
}