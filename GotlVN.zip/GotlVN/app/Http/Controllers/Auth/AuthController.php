<?php namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Contracts\Auth\Guard;
use Illuminate\Contracts\Auth\Registrar;
use Illuminate\Foundation\Auth\AuthenticatesAndRegistersUsers;
use Illuminate\Http\Request;
use Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use App\Models\User;
use DB;

class AuthController extends Controller {

	/*
	|--------------------------------------------------------------------------
	| Registration & Login Controller
	|--------------------------------------------------------------------------
	|
	| This controller handles the registration of new users, as well as the
	| authentication of existing users. By default, this controller uses
	| a simple trait to add these behaviors. Why don't you explore it?
	|
	*/

	use AuthenticatesAndRegistersUsers;

	/**
	 * Create a new authentication controller instance.
	 *
	 * @param  \Illuminate\Contracts\Auth\Guard  $auth
	 * @param  \Illuminate\Contracts\Auth\Registrar  $registrar
	 * @return void
	 */
	public function __construct(Guard $auth, Registrar $registrar)
	{
		$this->auth = $auth;
		$this->registrar = $registrar;

		$this->middleware('guest', ['except' => 'getLogout']);
	}
    
    public function getLogin(){
        if(Auth::check()){
			return Redirect::to('/');
		}
		return view('auth.login');
    }

    public function postLogin(Request $request){
		$this->validate($request, [
				'email' => 'required', 'password' => 'required',
				]);

		$credentials = array(
				'email'		=> $request->input('email'),
				'password'		=> $request->input('password')
		);
        
		if ($this->auth->attempt($credentials))
		{
            //update info login
            DB::table('tt_user')
                ->where('user_id', Auth::user()->user_id)
                ->update(['is_online' => 1]);
            
			return Redirect::to('/');
		}

		return redirect()->route('admin.login')
		->withInput($request->only('login_id', 'password'))
		->withErrors([
				'login_error' => trans('common.lg_msg_login_failed'),
				]);
	}
}
