/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50626
Source Host           : localhost:3306
Source Database       : gotl_vn

Target Server Type    : MYSQL
Target Server Version : 50626
File Encoding         : 65001

Date: 2016-01-04 00:20:27
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for sessions
-- ----------------------------
DROP TABLE IF EXISTS `sessions`;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `payload` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'serialize session string',
  `last_activity` int(11) NOT NULL COMMENT 'last activity timestamp',
  UNIQUE KEY `sessions_id_unique` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of sessions
-- ----------------------------

-- ----------------------------
-- Table structure for tm_grade
-- ----------------------------
DROP TABLE IF EXISTS `tm_grade`;
CREATE TABLE `tm_grade` (
  `grade_id` int(11) NOT NULL AUTO_INCREMENT,
  `grade_code` varchar(5) NOT NULL,
  `parent_code` varchar(5) NOT NULL,
  `grade_name` varchar(45) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`grade_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tm_grade
-- ----------------------------

-- ----------------------------
-- Table structure for tt_answer_history
-- ----------------------------
DROP TABLE IF EXISTS `tt_answer_history`;
CREATE TABLE `tt_answer_history` (
  `answer_history_id` int(11) NOT NULL AUTO_INCREMENT,
  `question_id` int(11) NOT NULL,
  `ask_user_id` int(11) DEFAULT NULL,
  `question_user_id` int(11) DEFAULT NULL,
  `content` text NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`answer_history_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tt_answer_history
-- ----------------------------

-- ----------------------------
-- Table structure for tt_billing
-- ----------------------------
DROP TABLE IF EXISTS `tt_billing`;
CREATE TABLE `tt_billing` (
  `billing_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `billing_name` varchar(45) NOT NULL,
  `identification` varchar(45) NOT NULL,
  `mobile` varchar(45) NOT NULL,
  `billing_address` varchar(255) NOT NULL,
  `payment_money` int(11) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`billing_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tt_billing
-- ----------------------------

-- ----------------------------
-- Table structure for tt_billing_history
-- ----------------------------
DROP TABLE IF EXISTS `tt_billing_history`;
CREATE TABLE `tt_billing_history` (
  `billing_history_id` int(11) NOT NULL,
  `billing_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `credit_after` varchar(45) NOT NULL,
  `credit_before` varchar(45) NOT NULL,
  `staff_cd` varchar(45) DEFAULT NULL,
  `staff_name` varchar(100) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`billing_history_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tt_billing_history
-- ----------------------------

-- ----------------------------
-- Table structure for tt_connect_question_answer
-- ----------------------------
DROP TABLE IF EXISTS `tt_connect_question_answer`;
CREATE TABLE `tt_connect_question_answer` (
  `question_id` int(11) NOT NULL,
  `connecting_user_id` int(11) NOT NULL,
  `status` int(2) NOT NULL COMMENT '0: Pending 1: Chờ được chọn lam người trả lời \r\n2: Được chọn lam người trả lời ',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`question_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tt_connect_question_answer
-- ----------------------------

-- ----------------------------
-- Table structure for tt_device
-- ----------------------------
DROP TABLE IF EXISTS `tt_device`;
CREATE TABLE `tt_device` (
  `device_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `uuid` varchar(32) DEFAULT NULL,
  `device_type` tinyint(1) DEFAULT NULL COMMENT '1: iphone 2: iPad 3: android\r\n4: web ',
  `device_token` varchar(255) DEFAULT NULL,
  `access_key` varchar(32) DEFAULT NULL COMMENT 'Sau khi đăng nhập thì sẽ sinh ra chuỗi access_key.  Chuỗi nay dùng để kiểm tra xem tài khoản đã Đăng nhập chưa\r\naccess_key là duy nhất access_key = MD5(user_pass_datetime)',
  `longitude` float DEFAULT NULL,
  `latitude` float DEFAULT NULL,
  `ip` varchar(20) DEFAULT NULL,
  `expire_date` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`device_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tt_device
-- ----------------------------
INSERT INTO `tt_device` VALUES ('1', '1', null, null, null, '3KZe04Rc0NrkK7umXYIagwlF5a8VykFE', null, null, null, '2016-01-03 18:47:37', '2016-01-03 14:29:23', null);

-- ----------------------------
-- Table structure for tt_earnings_history
-- ----------------------------
DROP TABLE IF EXISTS `tt_earnings_history`;
CREATE TABLE `tt_earnings_history` (
  `earnings_history_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `credits` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`earnings_history_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tt_earnings_history
-- ----------------------------

-- ----------------------------
-- Table structure for tt_notification
-- ----------------------------
DROP TABLE IF EXISTS `tt_notification`;
CREATE TABLE `tt_notification` (
  `notification_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `question_id` int(11) DEFAULT NULL,
  `message` text NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`notification_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tt_notification
-- ----------------------------

-- ----------------------------
-- Table structure for tt_question
-- ----------------------------
DROP TABLE IF EXISTS `tt_question`;
CREATE TABLE `tt_question` (
  `question_id` int(11) NOT NULL AUTO_INCREMENT,
  `ask_user_id` int(11) NOT NULL,
  `grade_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `image_path` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL COMMENT '0: Connecting\r\n1: Select answer 2: Processing 3: Explained 4: Rated (Finish)',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`question_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tt_question
-- ----------------------------

-- ----------------------------
-- Table structure for tt_rate_history
-- ----------------------------
DROP TABLE IF EXISTS `tt_rate_history`;
CREATE TABLE `tt_rate_history` (
  `rate_history_id` int(11) NOT NULL AUTO_INCREMENT,
  `question_id` int(11) NOT NULL,
  `asnswer_user_id` int(11) NOT NULL,
  `rate` int(11) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`rate_history_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tt_rate_history
-- ----------------------------

-- ----------------------------
-- Table structure for tt_user
-- ----------------------------
DROP TABLE IF EXISTS `tt_user`;
CREATE TABLE `tt_user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `is_online` tinyint(2) NOT NULL DEFAULT '0' COMMENT 'Để kiểm tra xem người dùng này có đang online hay không 0: Đang offline 1: Đang online\r\n',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tt_user
-- ----------------------------
INSERT INTO `tt_user` VALUES ('1', 'ddddd', '$2y$10$.V.pnUSnfnvhWuVr9/wC2eTmVnTILmfyq5n8yT', '0', '2016-01-03 14:29:22', null);

-- ----------------------------
-- Table structure for tt_user_grade
-- ----------------------------
DROP TABLE IF EXISTS `tt_user_grade`;
CREATE TABLE `tt_user_grade` (
  `user_grade_id` int(11) NOT NULL AUTO_INCREMENT,
  `grade_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`user_grade_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tt_user_grade
-- ----------------------------

-- ----------------------------
-- Table structure for tt_user_information
-- ----------------------------
DROP TABLE IF EXISTS `tt_user_information`;
CREATE TABLE `tt_user_information` (
  `user_information_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `full_name` varchar(45) DEFAULT NULL,
  `email` varchar(45) NOT NULL,
  `birthday` date DEFAULT NULL,
  `gender` tinyint(2) DEFAULT NULL,
  `account_fb` varchar(45) DEFAULT NULL,
  `account_type` tinyint(2) DEFAULT NULL COMMENT '0: nguoi hoi\r\n1: nguoi tra loi',
  `avatar_path` varchar(255) DEFAULT NULL,
  `credits` int(11) DEFAULT NULL,
  `rate` float DEFAULT NULL COMMENT 'Luu tru ket qua danh gia cua nguoi tra loi  rate = rate + danh gia cua cau hien tai  1 lan Rate toi da 5 sao ',
  `is_deleted` tinyint(2) DEFAULT '0' COMMENT '0: account dang duoc dung 1: account da bi xoa',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`user_information_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tt_user_information
-- ----------------------------
INSERT INTO `tt_user_information` VALUES ('1', '1', '', 'hien111@gmail.com', '0000-00-00', '0', null, null, null, null, null, '0', '2016-01-03 14:29:22', null);
